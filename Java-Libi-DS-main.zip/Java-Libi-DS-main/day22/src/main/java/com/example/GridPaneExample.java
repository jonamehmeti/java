package com.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class GridPaneExample extends Application {
    @Override
    public void start(Stage stage){

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10));

        grid.add(new Label("Product Name:"), 1, 0);
        grid.add(new TextField(), 1, 1);
        grid.add(new Label("Price:"), 1, 2);
        grid.add(new TextField(), 1, 3);

        
        Scene scene = new Scene(grid, 500, 500);
        stage.setScene(scene);
        stage.setTitle("Border Pane Example");
        stage.show();
    }

    
    public static void main(String[] args) {
        launch();
    }
}
