package com.example;

/**
 * Sample Skeleton for 'mainscene.fxml' Controller Class
 */

 import javafx.event.ActionEvent;
 import javafx.fxml.FXML;
 import javafx.scene.control.TextField;
 
 public class Controller {
 
    @FXML
    private TextField tfName;
 
     @FXML
     void onBtnClick(ActionEvent event) {
 
     }
 
     @FXML // This method is called by the FXMLLoader when initialization is complete
     void initialize() {
 
     }
 
 }
 
