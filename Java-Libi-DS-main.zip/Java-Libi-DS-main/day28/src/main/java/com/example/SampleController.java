package com.example;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class SampleController {

    @FXML
    private Label label1;
    @FXML
    private Button button1;

    @FXML
    private void handleButtonClick() {

        label1.setText("You clicked the button!");
        button1.setText("Clicked!");
        System.out.println("Button clicked!");
    }
}
