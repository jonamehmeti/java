package com.example;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Main extends Application {

    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        window.setTitle("Main Window");

        // Button to open ConfirmBox
        Button button = new Button("Click me");
        button.setOnAction(e -> closeProgram());

        // Handling the X button to close the window properly
        window.setOnCloseRequest(e -> {
            e.consume(); // Consume the close request event
            closeProgram();
        });

        Scene scene = new Scene(button, 400, 200);
        window.setScene(scene);
        window.show();
    }

    // Method to handle the closing logic
    private void closeProgram() {
        boolean result = ConfirmBox.display("Confirm", "Are you sure you want to close the program?");
        if (result) {
            window.close();
        }
    }
}